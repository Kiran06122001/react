
import "./styles.css";
import React from "react";
import Image from "./components/Image";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      photos: [],
      loading: true
    };
  }
  
  componentDidMount() {
    this.fetchPhotos();
  }
  
  fetchPhotos() {
    fetch('https://jsonplaceholder.typicode.com/albums/1/photos')
      .then(response => response.json())
      .then(photos => this.setState({ photos, loading: false }));
  }
  
  render() {
    const { loading, photos } = this.state;
    return (
      <div className="App">
        {loading ? (
          <div>Loading...</div>
        ) : (
          photos.map((photo) => {
            return <Image key={photo.id} photo={photo} />;
          })
        )}
      </div>
    );
  }
}