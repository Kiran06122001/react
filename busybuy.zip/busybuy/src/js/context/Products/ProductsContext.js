import { createContext } from "react";

const ProductsContext = createContext();

export default ProductsContext;
