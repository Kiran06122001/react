export const posts = [
  {
    id: 1,
    text: "Alone in the unspoilt wilderness",
    img:
      "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1174&q=80"
  },
  {
    id: 2,
    text: "Beautiful woodland path",
    img:
      "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80"
  },
  {
    id: 3,
    text: "Trees around a green lake",
    img:
      "https://images.unsplash.com/photo-1485281645044-77dde536d602?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1307&q=80"
  },
  {
    id: 4,
    text: "Night sky over a snowy forest",
    img:
      "https://images.unsplash.com/photo-1463780324318-d1a8ddc05a11?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 5,
    text: "The emphasis on the sunset",
    img:
      "https://images.unsplash.com/photo-1513010963904-2fefe6a92780?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  }
];
