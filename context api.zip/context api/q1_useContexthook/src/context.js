import { createContext } from "react";

export const cardContext = createContext();
