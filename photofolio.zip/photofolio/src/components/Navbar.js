import styles from "../css/navbar.module.css";
import img from '../assets/logo.png'
export const Navbar = () => {
  return (
    <div className={styles.navbar}>
      <div className={styles.logo} onClick={() => window.location.replace("/")}>
        <img src={img} alt="logo" />
        <span>PhotoFolio</span>
      </div>
    </div>
  );
};
