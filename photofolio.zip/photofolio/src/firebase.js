import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAm3sg97hdTZ9OvPvy6jsbtrt6EqOKwQUI",
  authDomain: "photofolio-b60bf.firebaseapp.com",
  projectId: "photofolio-b60bf",
  storageBucket: "photofolio-b60bf.appspot.com",
  messagingSenderId: "646117355664",
  appId: "1:646117355664:web:ba7c4c1d88376812652815"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
